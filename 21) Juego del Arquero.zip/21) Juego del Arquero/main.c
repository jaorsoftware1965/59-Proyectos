// ------------------------------------------------------------------------------------------------
// Juego "Arqueros en el Bosque" en C
// 0.- El Juego se Representa como una Matriz como la siguiente
//    A  B  C  D  E  F  G  H  I
//  1                         J2
//  2
//  3    X  X 
//  4          X  X     X 
//  5             X
//  6             X  X
//  7
//  8    X              X
//  9 J1                X

// 1.- J1 y J2 son las posiciones iniciales de cada jugador
// 2.- Cada X representa un Arbol que se genera aleatoriamente
// 3.- El Juego tiene 3 niveles: Facil, Normal y Dificil
// 4.- Para el Facil, el tablero es de 5x5
//     Para el Normal el tablero es de 7x7
//     Para el dificil el tablero es de 9x9
// 5.- El numero de arboles que se genera aleatoriamente es
//     de acuerdo a la dificultad: 5 para el Facil, 7 para
//     el Normal y 9 para el dificil
// 6.- El Juego se juega a 3 rounds; el que gane 2 gana
// 7.- Cada Round se generan los arboles y se debe eligir
//     que jugador inicia
// 8.- El juego finaliza si los arboles generados
//     No permiten contacto entre los Jugadores
// 9.- Un Jugador puede elegir moverse o lanzar una flecha
// A.- La Flecha solo puede llegar 5 posiciones en forma
//     vertical u horizontal.
// B.- La Flecha no puede rebasar los arboles
// C.- Si en el camino de la Flecha, esta alcanza la posición
//     de un jugador, es un punto para el jugador
// D.- El Juego puede finalizar cuando cualquier jugador lo
//     indique sin que haya puntaje para nadie

// E.- Cuando un jugador haya hecho 2 puntos, gana y el juego
//     finaliza y se debe preguntar si se desea jugar de nuevo
// ------------------------------------------------------------------------------------------------

// Librerias
#include "stdio.h"
#include "stdlib.h"
#include "time.h"

// Valores booleanos
#define FALSE 0
#define TRUE  1

// Valor Maximo del Tablero
#define MAX_TABLERO   9
#define AVANCE_FLECHA 5

// Niveles de Juego
char facil[10]   = "Facil";
char normal[10]  = "Normal";
char dificil[10] = "Dificil";

// Respuestas validas de Juego
#define SALIR              'S'  // Salir del Round
#define RENDIRSE           'R'  // Jugador se Rinde

#define MOVER_ARRIBA       '1'  // Moverse hacia arriba
#define MOVER_DERECHA      '2'  // Moverse hacia derecha
#define MOVER_ABAJO        '3'  // Moverse hacia abajo
#define MOVER_IZQUIERDA    '4'  // Moverse hacia izquierda

#define DISPARAR_ARRIBA    'A'  // Disparar hacia arriba
#define DISPARAR_DERECHA   'B'  // Disparar hacia derecha
#define DISPARAR_ABAJO     'C'  // Disparar hacia abajo
#define DISPARAR_IZQUIERDA 'D'  // Disparar hacia izquierda

// Matriz del Tablero
char tablero[MAX_TABLERO][MAX_TABLERO];

// Matriz de Busqueda
char busqueda[MAX_TABLERO][MAX_TABLERO];

// Variable para el Nivel de Juevo
int nivelJuego = 5; // 5 Es el default

// Variables para la posición de los Jugadores
int renJ1;
int colJ1;
int renJ2;
int colJ2;

// Variable para saber jugador en Turno
int jugadorInicia = 1; // Default quien inicia

// Prototipo de Funciones
void fnTableroInicializa();
void fnJugadoresInicializa();
void fnMarcadoresInicializa();
void fnJuegoInicializa();
int  fnGeneraNumeroAleatorio();
int  fnHayArbol(int ren, int col);
int  fnHayJugador(int ren, int col);
int  fnPosicionLibre(int ren, int col);
void fnColocaArbol(int ren, int col);
void fnMueveJugador(int jugador,char movimiento);
void fnTableroDespliega();
void fnArbolesGenera();
int  fnVerificaContacto(int ren, int col);
void pausa(const char *mensaje);
void fnTeclasDeJuego();
char fnRetornaLetraColumna(int columna);
int  fnDispararArriba(int  renglon,int  columna);
int  fnDispararDerecha(int  renglon,int  columna);
int  fnDispararAbajo(int  renglon,int  columna);
int  fnDispararIzquierda(int  renglon,int  columna);
int  fnDispararFlecha(char direccion, int jugador);

// Función que inicia el Juego
void fnIniciarJuego()
{
    // Variable en Turno
    int  enTurno;
    char ultimaJugada=' ';
    int  roundJugandose = 1;
    int  renJugada;
    int  colJugada;
    int  puntosJ1;
    int  puntosJ2;

    // Inicializa
    enTurno = jugadorInicia;

    // Variable para jugada
    char jugada;

   
    // Inicializa el Juego
    fnJuegoInicializa();

    // Coloca los Puntos
    puntosJ1 = 0;
    puntosJ2 = 0;
    
    // Ciclo para controlar el Juego
    while (puntosJ1 < 2 && puntosJ2 < 2)
    {
        // Despliega el Tablero
        fnTableroDespliega();

        // Desplegando Informacion Básica
        printf("Nivel de Juego:");
        
        // Verifica
        switch(nivelJuego)
        {
            case 5:printf("%s\n",facil);
                   break;
            case 7:printf("%s\n",normal);
                   break;
            case 9:printf("%s\n",dificil);
                   break;  
        }

        // Verifica ultima jugada
        printf("Round Jugandose          : %d\n", roundJugandose);
        printf("Rounds Ganados Jugador 1 : %d\n", puntosJ1);
        printf("Rounds Ganados Jugador 2 : %d\n", puntosJ2);
        printf("Ultima jugada: %c\n", ultimaJugada);
        printf("Posicion del Jugador 1   : %d,%c\n",renJ1+1,fnRetornaLetraColumna(colJ1+1));
        printf("Posicion del Jugador 2   : %d,%c\n",renJ2+1,fnRetornaLetraColumna(colJ2+1));

        // Solicitud
        printf("Jugador en Turno:%d\n",enTurno);
        printf("Indique accion a Jugar:");
        fflush(stdin);
        jugada = getchar();

        switch (jugada)
        {
            case 'S':
            case 's':// Salir
                     // Se inicializa el Juego
                     fnJuegoInicializa();
    
                     // Se actualiza enTurno
                     enTurno = jugadorInicia;

                     // Actualiza utlima jugada
                     ultimaJugada=jugada;

                     // Sale
                     break;
            case 'R':
            case 'r':// Rendirse
                     // Verifica jugador en Turno
                     if (enTurno==1)
                     {
                        // Incrementa puntaje
                        puntosJ2++;
                        
                        // Verifica si ha ganado
                        if (puntosJ2==2)                        
                           // Mensaje de Ganar
                           pausa("! Ha Ganado el Jugador 2");                        
                        else
                           // Mensaje de Ganar
                           pausa("! Se ha aumentado 1 Punto al Jugador 2");                        
                     }
                     else
                     {
                        // Incrementa puntaje
                        puntosJ1++;

                        // Verifica si ha ganado
                        if (puntosJ1==2)                        
                           // Mensaje de Ganar
                           pausa("! Ha Ganado el Jugador 1");
                        else
                           // Mensaje de Ganar
                           pausa("! Se ha aumentado 1 Punto al Jugador 1");                        
                     }

                     // Actualiza utlima jugada
                     ultimaJugada=jugada;

                     // Sale
                     break;

            case '1':// Mover Arriba
                     // Verifica jugador
                     if (enTurno==1)
                     {
                        renJugada=renJ1-1;
                        colJugada=colJ1;
                     }
                     else
                     {
                        renJugada=renJ2-1;   
                        colJugada=colJ2;
                     }
                     // Verifica que no salga del Tablero
                     if (renJugada < 0 )
                        pausa ("Error! Mover Arriba es fuera del Tablero");
                     else
                        // Verifica que esté libre
                        if (!fnPosicionLibre(renJugada,colJugada))
                           pausa ("Error! Mover Arriba es a posicion ocupada");                        
                        else  
                        {                      
                           // Mueve el Jugador
                           fnMueveJugador(enTurno,MOVER_ARRIBA);

                           // Cambia de Turno
                           if (enTurno==1)
                              enTurno=2;
                           else
                              enTurno=1; 

                           // Actualiza utlima jugada
                           ultimaJugada=jugada;  
                        }

                     // Sale   
                     break;         

            case '2':// Mover Derecha
                     if (enTurno==1)
                     {
                        colJugada=colJ1+1;
                        renJugada=renJ1;
                     }
                     else
                     {
                        colJugada=colJ2+1;   
                        renJugada=renJ2;
                     }
                     // Verifica que no salga del Tablero
                     if (colJugada == nivelJuego )
                        pausa ("Error! Mover Derecha es fuera del Tablero");
                     else
                        // Verifica que esté libre
                        if (!fnPosicionLibre(renJugada,colJugada))                        
                           pausa ("Error! Mover Derecha es a posicion Ocupada");
                        else  
                        {                      
                           // Mueve el Jugador
                           fnMueveJugador(enTurno,MOVER_DERECHA);
                           // Cambia de Turno
                           if (enTurno==1)
                              enTurno=2;
                           else
                              enTurno=1;   
                           // Actualiza utlima jugada
                           ultimaJugada=jugada;   
                        }

                     // Sale   
                     break;         

            case '3':// Mover Abajo
                     // Verifica jugador
                     if (enTurno==1)
                     {
                        renJugada=renJ1+1;
                        colJugada=colJ1;
                     }
                     else
                     {
                        renJugada=renJ2+1;   
                        colJugada=colJ2;
                     }
                     // Verifica que no salga del Tablero
                     if (renJugada == nivelJuego )
                        pausa ("Error! Mover Abajo es fuera del Tablero");
                     else
                        // Verifica que esté libre
                        if (!fnPosicionLibre(renJugada,colJugada))                        
                           pausa ("Error! Mover Abajo es a posicion Ocupada");
                        else               
                        {         
                           // Mueve el Jugador
                           fnMueveJugador(enTurno,MOVER_ABAJO);
                           
                           // Cambia de Turno
                           if (enTurno==1)
                              enTurno=2;
                           else
                              enTurno=1;   
                           // Actualiza utlima jugada
                           ultimaJugada=jugada;   
                        }
                     // Sale   
                     break;         

            case '4':// Mover Izquierda
                     // Verifica jugador
                     if (enTurno==1)
                     {
                        colJugada=colJ1-1;
                        renJugada=renJ1;
                     }
                     else
                     {
                        colJugada=colJ2-1;   
                        renJugada=renJ2;
                     }
                     // Verifica que no salga del Tablero
                     if (colJugada < 0 )
                        pausa ("Error! Mover a Izquierda es fuera del Tablero");
                     else
                        // Verifica que esté libre
                        if (!fnPosicionLibre(renJugada,colJugada))                        
                           pausa ("Error! Mover a Izquierda es a posicion Ocupada");
                        else                        
                        {
                           // Mueve el Jugador
                           fnMueveJugador(enTurno,MOVER_IZQUIERDA);                                                   
                           // Cambia de Turno
                           if (enTurno==1)
                              enTurno=2;
                           else
                              enTurno=1;   
                           // Actualiza utlima jugada
                           ultimaJugada=jugada;   
                        }
                     // Sale   
                     break;         

            case 'A':
            case 'a':// Disparar Arriba
                     if (fnDispararFlecha(DISPARAR_ARRIBA, enTurno))
                     {
                         // Dio en el jugador contrario
                        if (enTurno==1)
                        {
                           // Incrementa los Puntos del Jugador
                           puntosJ1++;

                           // Verifica si ha ganado
                           if (puntosJ1==2)
                           {
                              // Mensaje de Ganar
                              pausa("! Ha Ganado el Jugador 1");
                           }

                        }
                        else
                        {
                           // Incrementa los Puntos del Jugador
                           puntosJ2++;  

                           // Verifica si ha ganado
                           if (puntosJ2==2)
                           {
                              // Mensaje de Ganar
                              pausa("! Ha Ganado el Jugador 2");
                           }
                        }
                        
                        // Se inicializa el Juego
                        fnJuegoInicializa();
                        // Actualiza utlima jugada
                        ultimaJugada=' ';

                        // Se incrementa el Round
                        roundJugandose++;
    
                        // Se actualiza enTurno
                        enTurno = jugadorInicia;

                     }
                     else
                        // Cambia de Turno
                        if (enTurno==1)
                           enTurno=2;
                        else
                           enTurno=1;   

                     // Sale
                     break;         

            case 'B':
            case 'b':// Disparar Derecha
                     if (fnDispararFlecha(DISPARAR_DERECHA, enTurno))
                     {
                         // Dio en el jugador contrario
                        if (enTurno==1)
                        {
                           // Incrementa los Puntos del Jugador
                           puntosJ1++;

                           // Verifica si ha ganado
                           if (puntosJ1==2)
                           {
                              // Mensaje de Ganar
                              pausa("! Ha Ganado el Jugador 1");
                           }

                        }
                        else
                        {
                           // Incrementa los Puntos del Jugador
                           puntosJ2++;  

                           // Verifica si ha ganado
                           if (puntosJ2==2)
                           {
                              // Mensaje de Ganar
                              pausa("! Ha Ganado el Jugador 2");
                           }
                        }
                        
                        // Se inicializa el Juego
                        fnJuegoInicializa();
                        
                        // Actualiza utlima jugada
                        ultimaJugada=' ';

                        // Se incrementa el Round
                        roundJugandose++;
    
                        // Se actualiza enTurno
                        enTurno = jugadorInicia;

                     }
                     else
                        // Cambia de Turno
                        if (enTurno==1)
                           enTurno=2;
                        else
                           enTurno=1;   
 
                     // Sale
                     break;         

            case 'C':
            case 'c':// Disparar Abajo
                     if (fnDispararFlecha(DISPARAR_ABAJO, enTurno))
                     {
                         // Dio en el jugador contrario
                        if (enTurno==1)
                        {
                           // Incrementa los Puntos del Jugador
                           puntosJ1++;

                           // Verifica si ha ganado
                           if (puntosJ1==2)
                           {
                              // Mensaje de Ganar
                              pausa("! Ha Ganado el Jugador 1");
                           }

                        }
                        else
                        {
                           // Incrementa los Puntos del Jugador
                           puntosJ2++;  

                           // Verifica si ha ganado
                           if (puntosJ2==2)
                           {
                              // Mensaje de Ganar
                              pausa("! Ha Ganado el Jugador 2");
                           }
                        }
                        
                        // Se inicializa el Juego
                        fnJuegoInicializa();

                        // Actualiza utlima jugada
                        ultimaJugada=' ';

                        // Se incrementa el Round
                        roundJugandose++;
    
                        // Se actualiza enTurno
                        enTurno = jugadorInicia;

                     }
                     else
                        // Cambia de Turno
                        if (enTurno==1)
                           enTurno=2;
                        else
                           enTurno=1;   
                     // Sale
                     break;         

            case 'D':
            case 'd':// Disparar Izquierda
                     if (fnDispararFlecha(DISPARAR_IZQUIERDA, enTurno))
                     {
                         // Dio en el jugador contrario
                        if (enTurno==1)
                        {
                           // Incrementa los Puntos del Jugador
                           puntosJ1++;

                           // Verifica si ha ganado
                           if (puntosJ1==2)
                           {
                              // Mensaje de Ganar
                              pausa("! Ha Ganado el Jugador 1");
                           }

                        }
                        else
                        {
                           // Incrementa los Puntos del Jugador
                           puntosJ2++;  

                           // Verifica si ha ganado
                           if (puntosJ2==2)
                           {
                              // Mensaje de Ganar
                              pausa("! Ha Ganado el Jugador 2");
                           }
                        }
                        
                        // Se inicializa el Juego
                        fnJuegoInicializa();

                        // Actualiza utlima jugada
                        ultimaJugada=' ';

                        // Se incrementa el Round
                        roundJugandose++;
    
                        // Se actualiza enTurno
                        enTurno = jugadorInicia;

                     }
                     else
                        // Cambia de Turno
                        if (enTurno==1)
                           enTurno=2;
                        else
                           enTurno=1;   

                     // Sale
                     break;                  
            
            default:pausa("Jugada Incorrecta; verifique");
                    break;
        }
    }
}


// Función Principal
int main()
{
    // Para leer la opcion
    char opcion=' ';
    
    
    // Inicia la semilla para numeros aleatorios
    srand(time(NULL)); 

    // Ciclo Principal del Juego
    while (opcion !='0')
    {
        // Menu Principal
        printf("-------------------------------------\n");
        printf("Arqueros en el Bosque                \n");
        printf("-------------------------------------\n");
        printf("Menu Principal \n");
        printf("1.- Nivel de Juego (Activo:");
        switch (nivelJuego)
        {
            case 5:printf("%s)\n",facil);
                   break;
            case 7:printf("%s)\n",normal);
                   break;
            case 9:printf("%s)\n",dificil);
                   break;              
        }
        printf("2.- Quien Inicia (Activo:Jugador %d)\n"  ,jugadorInicia);
        printf("3.- Teclas para Jugar\n");
        printf("4.- Iniciar el Juego \n");
        printf("0.- Salir\n");
        
        // Limpiar el Buffer
        fflush(stdin);

        // Lee la opcion        
        opcion = getchar();
        
        // Evalua 
        switch (opcion)
        {
            case '0':// Sale del Juego
                     break;

            case '1':printf("Seleccione Nivel de Juego (F-Facil N-Normal D-Dificil):");
                     // Limpiar el Buffer
                     fflush(stdin);

                     // Lee la opcion        
                     opcion = getchar();

                     // Evalua opcion
                     switch (opcion)
                     {
                         case 'F':
                         case 'f':// Asigna Nivel 5
                                  nivelJuego=5;
                                  break;

                         case 'N':
                         case 'n':// Asigna Nivel 7
                                  nivelJuego=7;
                                  break;      

                         case 'D':
                         case 'd':// Asigna Nivel 9
                                  nivelJuego=9;
                                  break;

                         default:pausa("Error en Nivel");
                                  break;
                     }                             
                     break;

            case '2':printf("Seleccione que Jugador Inicia (1/2):");
                     // Limpiar el Buffer
                     fflush(stdin);

                     // Lee la opcion        
                     opcion = getchar();

                     // Evalua opcion
                     switch (opcion)
                     {
                         case '1':// Asigna Inicia J1
                                  jugadorInicia = 1;
                                  break;

                         case '2':// Asigna Inicia J2
                                  jugadorInicia = 2;
                                  break;      

                         default:pausa("Error en Jugador");
                                  break;
                     }                             
                     break;         
            case '3':fnTeclasDeJuego();
                     break;

            case '4':fnIniciarJuego();         
                     break;

            default:pausa("Opcion No valida\n");
                    break;
        }

    }
    // Mensaje Final
    printf("Programa Terminado ...");    
}

// Metodo para inicializar la Matriz
void fnTableroInicializa()
{
    // Ciclo para inicializar el Tablero
    for (int ren = 0; ren < nivelJuego; ren++)
        for (int col = 0; col < nivelJuego; col++)
        {
            // Inicia tablero de Juego
            tablero[ren][col] ='.';
            // Inicia tablero de Busqueda
            busqueda[ren][col]=' ';
        }

    // Mensaje
    printf("El Tablero ha sido inicializado \n");
}

// Método para inicializar Jugadores
void fnJugadoresInicializa()
{
    // Coloca los jugadores en su posición inicial
    renJ1 =nivelJuego-1;
    colJ1 =0;
    renJ2 =0;
    colJ2 =nivelJuego-1;

    // Coloca los jugadores
    tablero[renJ1][colJ1]='1';
    tablero[renJ2][colJ2]='2';
}


void fnJuegoInicializa()
{
    // Inicializa Tablero
    fnTableroInicializa();
    
    // Inicializa Jugadores
    fnJugadoresInicializa();

    // Genera los Arboles
    fnArbolesGenera();
}

// Generar Numero Aleatorio
int fnGeneraNumeroAleatorio()
{
    // Variable de resultado
    int resultado;   

    // Genera el Numero aleatorio
    resultado = rand() % nivelJuego; 

    // Devuelve el Numero
    return resultado;
}

// Funcion que verifica si hay un arbol en la posición
int fnHayArbol(int ren, int col)
{
    // Verifica si hay Arbol
    if (tablero[ren][col]=='X')
       return TRUE;
    else
       return FALSE;   
}

int fnEstaLibre(int ren, int col)
{
    // Verifica si hay Arbol
    if (tablero[ren][col]=='.')
       return TRUE;
    else
       return FALSE;   
}


// Funcion que verifica si hay un Jugador
int fnHayJugador(int ren, int col)
{
    // Verifica si hay Jugador 1
    if (tablero[ren][col]=='1' || tablero[ren][col]=='2')    
       return TRUE;
    else
       return FALSE;   
        
}

// Verifica si la posición está libre
int  fnPosicionLibre(int ren, int col)
{
    // Verifica si está libre
    if (tablero[ren][col]=='.')
       return TRUE;
    else
       return FALSE;
}



// Funcion que verifica si hay un arbol en la posición
void fnColocaArbol(int ren, int col)
{
    // Coloca un Arbol (X)
    tablero[ren][col]='X';
}

// Función que mueve el Jugador
void fnMueveJugador(int jugador,
                    char movimiento)
{
    // Verifica si es el jugador 1
    if (jugador== 1)
    {
       // Quita el Jugador de Su posición Actual
       tablero[renJ1][colJ1]='.';

       // Verifica hacia donde mover
       switch(movimiento)
       {
            case MOVER_ARRIBA:
                 // Decrementa el Renglon
                 renJ1--;                 
                 break;
            case MOVER_DERECHA:
                 // Incrementa la Columna
                 colJ1++;
                 break;
            case MOVER_ABAJO:
                 // Incrementa el Renglon
                 renJ1++;                 
                 break;
            case MOVER_IZQUIERDA:
                 // Decrementa la Columna
                 colJ1--;
                 break;
       }
       // Coloca al Jugador en la nueva posición
       tablero[renJ1][colJ1]='1';
    }
    else
    {
       // Quita el Jugador de Su posición Actual
       tablero[renJ2][colJ2]='.';
       
       // Verifica hacia donde mover
       switch(movimiento)
       {
            case MOVER_ARRIBA:
                 // Decrementa el Renglon
                 renJ2--;                 
                 break;
            case MOVER_DERECHA:
                 // Incrementa la Columna
                 colJ2++;
                 break;
            case MOVER_ABAJO:
                 // Incrementa el Renglon
                 renJ2++;                 
                 break;
            case MOVER_IZQUIERDA:
                 // Decrementa la Columna
                 colJ2--;
                 break;
       }

       // Coloca al jugador en la nueva posición
       tablero[renJ2][colJ2]='2';
    }
}

// Funciòn para desplegar el Tablero
void fnTableroDespliega()
{
    // Mensaje del Tabler
    printf("Tablero Actual\n");
    // Imprime los encabezados
    if (nivelJuego==5)
    {
       printf("   A B C D E  \n");
       printf("   ---------- \n");
    }
    else   
    if (nivelJuego==7)
    {
       printf("   A B C D E F G  \n");
       printf("   -------------- \n");
    }
    else
    {
       printf("   A B C D E F G H I  \n");
       printf("   ------------------ \n");
    }


    // Ciclo
    for (int ren=0; ren < nivelJuego; ren++)
    {        
        // Imprime el Renglo
        printf("%d |",ren+1);
        for (int col=0; col < nivelJuego; col++)        
            printf("%c ",tablero[ren][col]);

        // Cambia de Linea
        printf("|\n");        
    }

    // Imprime los encabezados
    if (nivelJuego==5)
       printf("   ---------- \n");
    else   
    if (nivelJuego==7)
       printf("   -------------- \n");
    else
       printf("   ------------------ \n");    
}

// Función que genera los arboles
void fnArbolesGenera()
{
    // Conteo de Arboles generados
    int arbolesGenerados=0;
    int renglon;
    int columna;

    // Ciclo
    while (arbolesGenerados<nivelJuego)
    {
        // genera renglo y columna aletarrios
        renglon = fnGeneraNumeroAleatorio();
        columna = fnGeneraNumeroAleatorio();

        // Verifica si No hay un arbol en la posición
        if (fnEstaLibre(renglon,columna))
        {
            // Coloca arbol en la Posicion
            fnColocaArbol(renglon,columna);

            // Incrementa el contador de arboles generados
            arbolesGenerados++;
        }
    }
    // Mensaje
    printf("Se generaron los arboles\n");

    // Verifica si hay contacto en el Juego
    if (!fnVerificaContacto(renJ1,colJ1))   
        pausa("! ADVERTENCIA ! NO Hay Contacto entre los 2 Jugadores \n");
}

int fnVerificaContacto(int ren, int col)
{
    // Verifica si ya fue revisado
    if (busqueda[ren][col]=='B')
       return FALSE;
    else
       busqueda[ren][col]='B';

    // Verifica ren correcto
    if (ren < 0 || ren == nivelJuego ||
        col < 0 || col == nivelJuego)       
        return FALSE;
    else    
    // Verifica si hay Arbol
    if (tablero[ren][col]=='X')
       return FALSE;
    else   
    // Verifica si el Jugador 1 está en esta posición
    if (tablero[ren][col]=='2')
       return TRUE;
    else
    {
        if (fnVerificaContacto(ren-1,col)) // Arriba
          return TRUE;
        else
        if (fnVerificaContacto(ren,col+1))   // Derecha
           return TRUE;
        else   
        if (fnVerificaContacto(ren+1,col)) // Abajo
           return TRUE;
        else   
        if (fnVerificaContacto(ren,col-1)) // Izquierda
           return TRUE;
        else   
           return FALSE;        
    }
}

// Funcion para poner un mensaje y pausar
void pausa(const char *mensaje)
{
    // Despliega el Mensaje
    printf("%s\n",mensaje);
    printf("Presione Enter para Continuar");

    // Libera el Buffer
    fflush(stdin);

    // Espera a que presione enter
    getchar();
    printf("\n");
}

// Teclas de Juego
void fnTeclasDeJuego()
{
   printf("Teclas de Juego Posibles:\n");
   printf("S - SALIR DEL ROUND\n");
   printf("R - RENDIRSE\n");
   printf("1 - MOVER_ARRIBA\n");
   printf("2 - MOVER_DERECHA\n");
   printf("3 - MOVER_ABAJO\n");
   printf("4 - MOVER_IZQUIERDA\n");
   printf("A - DISPARAR_ARRIBA\n");
   printf("B - DISPARAR_DERECHA\n");
   printf("C - DISPARAR_ABAJO\n");
   printf("D - DISPARAR_IZQUIERDA\n");
   pausa("");
}

// Retorna la Letra de la Columna
char fnRetornaLetraColumna(int columna)
{
   // Variable de Resultado
   char resultado=' ';

   // Evalua
   switch (columna)
   {
      case 1:resultado ='A';
             break;
      case 2:resultado ='B';
             break;
      case 3:resultado ='C';
             break;
      case 4:resultado ='D';
             break;
      case 5:resultado ='E';
             break;
      case 6:resultado ='F';
             break;
      case 7:resultado ='G';
             break;
      case 8:resultado ='H';
             break;
      case 9:resultado ='I';
             break;
   }

   // Retorna
   return resultado;
}

// función para disparar flecha arriba
int fnDispararArriba(int  renglon,
                     int  columna)
{
    // Resultado 
    int resultado = TRUE;

    // fuera del Tablero
    int flechaSalioDelTablero = FALSE;

    // Avance de la flecha
    int avanceFlecha = 0;
    
    // Ciclo para buscar hacia arriba
    while (avanceFlecha < AVANCE_FLECHA)
    {
        // Incrementa el Avance de la Flecha
        avanceFlecha++;

        // decremanta el renglon
        renglon--;

        // Verifica que no haya salido del tablero
        if (renglon < 0)
        {
           // Salio del Tablero
           flechaSalioDelTablero = TRUE;

           // Cambia el Resultado
           resultado = FALSE;

           // Sale del Ciclo
           break;
        }

        // Verifica si hay un árbol
        if (fnHayArbol(renglon,columna))
        {
           // Cambia el Resultado
           resultado = FALSE;

           // Mensaje
           pausa("La Flecha se ha impactado con un Arbol");

           // Sale
           break;
        }
        else
        if (fnHayJugador(renglon,columna))        
        {
            // Sale
            break;
        }
    }

    // Verifica si ha alcanzado oponente
    if (resultado)
       pausa("! Exito ! La Flecha ha alcanzado al oponente");
    else   
    // Verifica si la flecha sale del tablero
    if (flechaSalioDelTablero)
       pausa("La Flecha salio del Tablero sin encontrar oponente");
    else
    // Verifica
    if (avanceFlecha == AVANCE_FLECHA)
       pausa("La Flecha alcanzo su distancia sin encontrar oponente");

    // Devuelve el resultado
    return resultado;   
}

// función dispara flecha hacia Derecha
int fnDispararDerecha(int  renglon,int  columna)
{
    // Resultado 
    int resultado = TRUE;

    // fuera del Tablero
    int flechaSalioDelTablero = FALSE;

    // Avance de la flecha
    int avanceFlecha = 0;
    
    // Ciclo para buscar hacia arriba
    while (avanceFlecha < AVANCE_FLECHA)
    {
        // Incrementa el Avance de la Flecha
        avanceFlecha++;

        // incrementa la columna
        columna++;

        // Verifica que no haya salido del tablero
        if (renglon == nivelJuego)
        {
           // Salio del Tablero
           flechaSalioDelTablero = TRUE;

           // Cambia el Resultado
           resultado = FALSE;

           // Sale del Ciclo
           break;
        }

        // Verifica si hay un árbol
        if (fnHayArbol(renglon,columna))
        {
           // Cambia el Resultado
           resultado = FALSE;

           // Mensaje
           pausa("La Flecha se ha impactado con un Arbol");

           // Sale
           break;
        }
        else
        if (fnHayJugador(renglon,columna))        
        {
            // Sale
            break;
        }
    }

    // Verifica si ha alcanzado oponente
    if (resultado)
       pausa("! Exito ! La Flecha ha alcanzado al oponente");
    else   
    // Verifica si la flecha sale del tablero
    if (flechaSalioDelTablero)
       pausa("La Flecha salio del Tablero sin encontrar oponente");
    else
    // Verifica
    if (avanceFlecha == AVANCE_FLECHA)
       pausa("La Flecha alcanzo su distancia sin encontrar oponente");

    // Devuelve el resultado
    return resultado;   
}


// función para disparar flecha abajo
int fnDispararAbajo(int  renglon,
                    int  columna)
{
    // Resultado 
    int resultado = TRUE;

    // fuera del Tablero
    int flechaSalioDelTablero = FALSE;

    // Avance de la flecha
    int avanceFlecha = 0;
    
    // Ciclo para buscar hacia arriba
    while (avanceFlecha < AVANCE_FLECHA)
    {
        // Incrementa el Avance de la Flecha
        avanceFlecha++;

        // incrementa el renglon
        renglon++;

        // Verifica que no haya salido del tablero
        if (renglon == nivelJuego)
        {
           // Salio del Tablero
           flechaSalioDelTablero = TRUE;

           // Cambia el Resultado
           resultado = FALSE;

           // Sale del Ciclo
           break;
        }

        // Verifica si hay un árbol
        if (fnHayArbol(renglon,columna))
        {
           // Cambia el Resultado
           resultado = FALSE;

           // Mensaje
           pausa("La Flecha se ha impactado con un Arbol");

           // Sale
           break;
        }
        else
        if (fnHayJugador(renglon,columna))        
        {
            // Sale
            break;
        }
    }

    // Verifica si ha alcanzado oponente
    if (resultado)
       pausa("! Exito ! La Flecha ha alcanzado al oponente");
    else   
    // Verifica si la flecha sale del tablero
    if (flechaSalioDelTablero)
       pausa("La Flecha salio del Tablero sin encontrar oponente");
    else
    // Verifica
    if (avanceFlecha == AVANCE_FLECHA)
       pausa("La Flecha alcanzo su distancia sin encontrar oponente");

    // Devuelve el resultado
    return resultado;   
}

// función dispara flecha hacia Izquierda
int fnDispararIzquierda(int  renglon,int  columna)
{
    // Resultado 
    int resultado = TRUE;

    // fuera del Tablero
    int flechaSalioDelTablero = FALSE;

    // Avance de la flecha
    int avanceFlecha = 0;
    
    // Ciclo para buscar hacia arriba
    while (avanceFlecha < AVANCE_FLECHA)
    {
        // Incrementa el Avance de la Flecha
        avanceFlecha++;

        // decrementa la columna
        columna--;

        // Verifica que no haya salido del tablero
        if (renglon == nivelJuego)
        {
           // Salio del Tablero
           flechaSalioDelTablero = TRUE;

           // Cambia el Resultado
           resultado = FALSE;

           // Sale del Ciclo
           break;
        }

        // Verifica si hay un árbol
        if (fnHayArbol(renglon,columna))
        {
           // Cambia el Resultado
           resultado = FALSE;

           // Mensaje
           pausa("La Flecha se ha impactado con un Arbol");

           // Sale
           break;
        }
        else
        if (fnHayJugador(renglon,columna))        
        {
            // Sale
            break;
        }
    }

    // Verifica si ha alcanzado oponente
    if (resultado)
       pausa("! Exito ! La Flecha ha alcanzado al oponente");
    else   
    // Verifica si la flecha sale del tablero
    if (flechaSalioDelTablero)
       pausa("La Flecha salio del Tablero sin encontrar oponente");
    else
    // Verifica
    if (avanceFlecha == AVANCE_FLECHA)
       pausa("La Flecha alcanzo su distancia sin encontrar oponente");

    // Devuelve el resultado
    return resultado;   
}


// Funcion para Disparar Flecha
int fnDispararFlecha(char direccion, int jugador)
{
    // Variable de Resultado
    int resultado = FALSE;

    // Posición Inicial del Disparo
    int renDisparo;
    int colDisparo;

    if (jugador==1)
    {
       // Obtiene la posición inicial del disparo
       renDisparo = renJ1;
       colDisparo = colJ1;  
    }
    else
    {
      // Obtiene la posición inicial del disparo
      renDisparo = renJ2;
      colDisparo = colJ2;
    }
   
   // Evalua Direccion
   switch (direccion)
   {
         case DISPARAR_ARRIBA:
              
              // Verifica disparo
              if (fnDispararArriba(renDisparo,colDisparo))
                 // Resultado
                 resultado = TRUE;                                         

              // Sale   
              break;   

         case DISPARAR_DERECHA:
              // Verifica disparo
              if (fnDispararDerecha(renDisparo,colDisparo))
                 // Resultado
                 resultado = TRUE;                                         

              // Sale   
              break;        

         case DISPARAR_ABAJO:
              // Verifica disparo
              if (fnDispararAbajo(renDisparo,colDisparo))
                 // Resultado
                 resultado = TRUE;                                         

              // Sale   
              break;             

         case DISPARAR_IZQUIERDA:
              // Verifica disparo
              if (fnDispararIzquierda(renDisparo,colDisparo))
                 // Resultado
                 resultado = TRUE;                                         

              // Sale   
              break;        

    }    

    // Devuelve el resultado
    return resultado;
}
