// --------------------------------------
// Lucia Pinero ci: 50800545
// Nadia inthamoussu ci: 46500149
// Principios de Programación 2021
// --------------------------------------

// Librerias
#include <conio.h>
#include <limits>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <iostream> 
#include <stdio.h> 
#include <string.h> 

// Constantes
#define FALSE 0
#define TRUE  1
#define MAX              26    // Maxima Longitud del Tablero
#define FICHA_JUG1       '1'   // Ficha del Jugador 1
#define FICHA_JUG2       '2'   // Ficha del Jugador 2
#define FICHA_ARBOL      'X'   // Ficha del Arbol
#define LIMPIAR_PANTALLA "cls" // Comando para Limpiar Pantalla

// Teclas de Juego
#define SALIR            'q'
#define RENDIRSE         'r'
#define MOV_ARRIBA       'w'
#define MOV_ABAJO        's'
#define MOV_DERECHA      'd'
#define MOV_IZQUIERDA    'a'
#define FLECHA_ARRIBA    'y'
#define FLECHA_ABAJO     'h'
#define FLECHA_DERECHA   'j'
#define FLECHA_IZQUIERDA 'g'


// Definimos el Espacio de Nombres
using namespace std;

// Variables globales
int  dim;                // Dimension del Juego
char bosque [MAX][MAX];  // Tablero
int  enTurno;            // Que jugador está en turno
int  jugadorInicia;      // Jugador que Inicia


// Estructura para los Jugadores
struct jugador 
{  
    // Nombre del Jugador
    string nombre;    
    
    // Posición actual en el Tablero
    int fil;
    int col;

}jug_1,jug_2; // Variables para los Jugadores

// Prototipo de Funciones
void fnLimpiarPantalla();
void fnEsperar();
void fnBienvenida();
int  fnGeneraNumeroAleatorio();
void menu(); 
void menu_jugador(int roundJugandose);
void menu_partida();
void imprimir_matriz();
void fnBosque();
int  movimiento(char tecla);
int  control_mov(int fila, int columna);
int  ocupado_arbol(int fila, int columna);
int  fnPosicionLibre(int fila, int columna);
void iniciar();
int  fnDispararArriba();
int  fnDispararDerecha();
int  fnDispararAbajo();
int  fnDispararIzquierda();
int  fnHayJugador(int ren, int col);

// Función Principal
int main()
{
    // Inicializa la Generación de Aleatorios
    srand(time(NULL));

    // Variable para leer la opcion
    int opcion;

    // Ejecuta la Bienvenida y Reglas del Juego                            
    fnBienvenida();

    // Despliega el Menu inicial
    menu();

    // Lee la opcion
    cin >> opcion;    

    // Limpia la Pantalla
    fnLimpiarPantalla();

    // Verifica que selecciono
    if (opcion==1)
    { 
        // Despliega el Menu de la Partida
        menu_partida();

        // Genera el Bosque
        fnBosque();

        // Iniciar el Juego
        iniciar();        
    }     
    else
    {
        cout << "Lo entendemos el juego es demasiado dificil para usted" << endl;
        cout << "Programa terminado" << endl;
    }

    // Fin del Programa         
    return 0;     
}

// Función para Limpiar la Pantalla 
void fnLimpiarPantalla()
{
   // Ejecuta el Comando
   //system (LIMPIAR_PANTALLA);
}

// Función de Bienvenida y Reglas del Juego
void fnBienvenida()
{
    cout << "<<<<<<<<<<<<<<<  BIENVENIDOS  >>>>>>>>>>>>>>>"<< endl <<endl;
    cout << "             Arqueros en el Bosque   "<<endl<<endl;
    cout << "Objetivo del juego: Eliminar al rival con un flechazo, "<<endl;
    cout << " gana el mejor de tres round."<<endl<<endl;
    cout << "REGLAS DE JUEGO"<< endl;
    cout << "     1. Eleccion de que Arquero comienza la partida. "<< endl;
    cout << "     2. Eleccion del bosque en el que desean jugar."<< endl;
    cout << "     3. En cada turno el Arquero elige si moverse. "<<endl;
    cout << "           un lugar o disparar un flechazo."<<endl;
    fnEsperar();
}
    
void menu() 
{ 
    // Menu Inicial  para ingresar a nueva partida o salir del juego//
    cout << "Bienvenido al menu de Partidas"<< endl<<endl;
    cout << "Ingrese la opcion que desee:" << endl;
    cout << "1. Ingresar a la nueva partida." << endl;
    cout << "0. Salir" << endl;
} 

// Generar Numero Aleatorio
int fnGeneraNumeroAleatorio()
{
    // Variable de resultado
    int resultado;   

    // Genera el Numero aleatorio
    resultado = rand() % dim; 

    // Devuelve el Numero
    return resultado;
}

 // función para ver quien inicia
 void menu_partida()
 {
    // ingresar nombres de los jugadores y quien desea comenzar//
    // int inicia; no es necesaria por enTurno
    cout << "Ingrese el nombre del jugador 1: \n";
    cin  >> jug_1.nombre;
    cout << "Ingrese el nombre del jugador 2: \n";
    cin  >> jug_2.nombre;

    // Limpia la Pantalla
    fnLimpiarPantalla();
    
    // Ciclo para saber quien inicia
    do
    {
        // Pregunta quien Comienza
        cout << "Quien comienza:" << endl;
        cout << "1-->" <<  jug_1.nombre << endl;
        cout << "2-->" <<  jug_2.nombre << endl;

        // Lee quien comienza
        cin >> jugadorInicia;

        // Lo coloca en Turno
        enTurno = jugadorInicia;

        // Limpia la Pantalla
        fnLimpiarPantalla();

        // Verifica jugador
        switch(enTurno)
        {
            case 1:
                 cout << "Comienza jugando " << jug_1.nombre << endl;
                 break;
            case 2:                
                 cout << "Comienza jugando " << jug_2.nombre << endl;
                 break;
            default:
                 cout<<"opcion incorrecta"<<endl;
        }
    }
    while(enTurno!=1 && enTurno != 2);
  }

// Función para crear el Bosque, ubicar jugadores y arboles
void fnBosque()
{   
    // Ciclo para crear el Bosque
    do
    {
        // Mensaje
        cout << "Ingrese la dimension que desea tenga el bosque entre 6-25: "<< endl;
        
        // Lee la dimensión
        cin  >> dim;
        
        // Limpia la Pantalla
        fnLimpiarPantalla();
    }
    while ((dim>25)||(dim<6));

    // Ciclo para inicializar el Bosque
    for (int fila = 0; fila < dim; fila ++) 
    {
        for (int columna = 0; columna < dim; columna++) 
        {
            // Coloca espacios en toda la matriz
            bosque[fila][columna] = ' '; 
        }
    }
    

    // Ubicamos el Jugador
    bosque[dim-1][0] = FICHA_JUG1; // ubicamos el jugador 1
    bosque[0][dim-1] = FICHA_JUG2; // ubicamos el jugador 2

    // Colocamos las posiciones de los jugadores en sus
    // Variables
    jug_1.fil = dim-1;
    jug_1.col = 0;
    jug_2.fil = 0;
    jug_2.col = dim-1;

    // Calcula el 15% arboles a generar
    int aprox_arbol = (((dim*dim)*15)/ 100); 

    // Ciclo para generar los arboles
    for (int cuentaArboles = 0; cuentaArboles <aprox_arbol; cuentaArboles++)
    {
        // Ciclo
        while (true)
        {
            // Obtiene Aleatorios para fila y columna
            int fila    = fnGeneraNumeroAleatorio();
            int columna = fnGeneraNumeroAleatorio();

            // Verifica si está desocupado
            if (bosque[fila][columna]==' ')
            {
                // Inserta el Arbol
                bosque[fila][columna]= FICHA_ARBOL;

                // Sale del Ciclo 
                break;
            }            
        } 
    }
 }

 // Función para el Menu del Jugador   
 void menu_jugador(int roundJugandose)
 {    
    // Peticion e informacion 
    cout << "Jugando el Round :" << roundJugandose << endl;
    cout << "Ingrese la opcion que desee:" << endl;
    cout << "q---salir"<<endl;
    cout << "r---rendirse"<<endl;
    cout << "w---moverse hacia arriba"<<endl;
    cout << "s---moverse hacia abajo"<<endl;
    cout << "d---moverse hacia la derecha"<<endl;
    cout << "a---moverse hacia la izquierda"<<endl;
    cout << "y---flecha hacia arriba"<<endl;
    cout << "h---flecha hacia abajo"<<endl;
    cout << "j---flecha hacia la derecha"<<endl;
    cout << "g---flecha hacia la izquierda"<<endl;    
}

 // Función para fnEsperar 
 void fnEsperar() 
 { 
    // Mensaje
    cout << "\n[ PRESIONE ENTER PARA CONTINUAR ]";
    fflush(stdin);
    
    // Espera a que de enter
    cin.ignore (100000, '\n' );
    
    // Limpia la Pantalla
    fnLimpiarPantalla();
}
    
 

// Función que mueve al jugador      
int movimiento (char opcion)
{   
    // Variable de Resultado
    int resultado = FALSE;

    // Variables para el Movimiento
    int  fila;
    int  columna;
    char ficha;

    // Verifica quien es el jugador en turno
    // para obtener coordenadas
    if (enTurno==1)  
    {
       // Obtiene los datos del primer jugador
       fila    = jug_1.fil;
       columna = jug_1.col;
       ficha   = FICHA_JUG1;
    }
    else
    {
       // Obtiene los datos del segundo jugador
       fila    = jug_2.fil;
       columna = jug_2.col;
       ficha   = FICHA_JUG2;
    }

    // Verifica opción
    switch (opcion)
    {
        case MOV_ARRIBA: 
             // Decrementa la Fila porque va hacia arriba
             fila = fila - 1;
             if (control_mov(fila,columna) && 
                 fnPosicionLibre(fila,columna))
             {
                 // Mueve el Jugador
                 // Elimina donde esta actualmente
                 bosque[fila+1][columna]=' '; 
                 
                 // Lo mueve a la nueva posición
                 bosque[fila][columna]=ficha; 

                 // Mensaje
                 cout << "Se ha movido el Jugador " << ficha << " hacia arriba."  << endl;

                 // ACtualiza resultado
                 resultado = TRUE;
             }
             break;

        case MOV_ABAJO: 
             // Incrementa la Fila porque va hacia abajo
             fila = fila + 1;
             if (control_mov(fila,columna) && 
                 fnPosicionLibre(fila,columna))
             {
                 // Mueve el Jugador
                 // Elimina donde esta actualmente
                 bosque[fila-1][columna]=' '; 
                 
                 // Lo mueve a la nueva posición
                 bosque[fila][columna]=ficha; 

                 // Mensaje
                 cout << "Se ha movido el Jugador " << ficha << " hacia abajo." << endl;

                 // Actualiza Resultado
                 resultado = TRUE;
             }     
             break;
        case MOV_DERECHA: 
             // Incrementa la Columna porque va hacia derecha
             columna = columna + 1;
             if (control_mov(fila,columna) && 
                 fnPosicionLibre(fila,columna))
             {
                 // Mueve el Jugador
                 // Elimina donde esta actualmente
                 bosque[fila][columna-1] = ' '; 
                 
                 // Lo mueve a la nueva posición
                 bosque[fila][columna] = ficha; 

                 // Mensaje
                 cout << "Se ha movido el Jugador " << ficha << " hacia la derecha." << endl;

                 // Actualiza Resultado
                 resultado = TRUE;
             }
             break;
        case MOV_IZQUIERDA: 
             // Decrementa la Columna porque va hacia izquierda
             columna = columna - 1;
             if (control_mov(fila,columna) && 
                 fnPosicionLibre(fila,columna))
             {
                 // Mueve el Jugador
                 // Elimina donde esta actualmente
                 bosque[fila][columna+1] = ' '; 
                 
                 // Lo mueve a la nueva posición
                 bosque[fila][columna] = ficha; 

                 // Mensaje
                 cout << "Se ha movido el Jugador " << ficha << " hacia la izquierda." << endl;

                 // Actualiza Resultado
                 resultado = TRUE;
             } 
             break;                       
    }

    // Verifico si actualizo posiciones
    if (resultado)
       if (enTurno==1)
       {
          // Actualizo J1
          jug_1.fil = fila;
          jug_1.col = columna;
       }
       else
       {
          // Actualizo J2
          jug_2.fil = fila;
          jug_2.col = columna;
       }

    

    // Devuelve el resultado
    return resultado;
}  

// Función para controlar que no se salga del Bosque
int control_mov (int fila, int columna)
{ 
    //para que el jugador no se salga del bosque
    if (fila <0 || fila==dim || columna <0 || columna==dim)
    {
       // No es valido el movimiento
       cout << "Movimiento Fuera del Tablero" << endl;
       fnEsperar();
       return FALSE;
    }
    else 
       // Si es valido
       return TRUE;
}

// Verifica si hay un arbol
int ocupado_arbol(int fila, int columna) 
{
    // Verifica si hay un árbol
    if (bosque [fila][columna]==FICHA_ARBOL)
    {
        // Si hay un arbol
        return TRUE;
    }
    else
        // NO hay un arbol
        return FALSE; 
}

// Verifica si la posición está libre
int  fnPosicionLibre(int fila, int columna)
{
    // Verifica posición libre
    if (bosque[fila][columna]==' ')
       // Si está libre
       return TRUE;
    else
    {
        // Mensaje
        cout << "La posicion esta ocupada " <<  endl;
        fnEsperar();
        // No está libre
        return FALSE;   
    }
}
   

// Se inicia el Juego
void iniciar ()
{      
    // Variable para Controlar el Juego
    int  roundJugandose=1;
    char ultima_jugada;
    int  puntos_juga_1 =  0;
    int  puntos_juga_2 =  0;    
    char jugada; 
    bool impacto;
    
    // Ciclo que controla el Juego        
    while (puntos_juga_1 < 2 && 
           puntos_juga_2 < 2)
    {
        // Imprime la Matriz
        imprimir_matriz();           

        // Despliega el Menu del Jugador
        menu_jugador(roundJugandose);
        
        // Despliega quien Juega
        if (enTurno==1)            
        {
            // Mensaje
            cout << "Jugando " <<  jug_1.nombre << endl; 
            cout << "Puntos :" << puntos_juga_1 << endl;           
        }
        else
        {
            // Mensaje 
            cout << "Jugando " << jug_2.nombre << endl;
            cout << "Puntos :" << puntos_juga_2 << endl;           
        }            
        // Lee la opcion
        cin >> jugada;

        // Verifica si es salir
        if (jugada == SALIR)
        {
            // Genera los arboles de Nuevo
            cout << "Has salido de la Partida " << endl;
            cout << "Se inicia de nuevo el round " << roundJugandose << endl;
            fnBosque();
            cout << "Se ha generado el Bosque" << endl;

            // Se coloca el jugador en Turno
            enTurno = jugadorInicia;

        }
        else
        if (jugada == RENDIRSE)
        {
           // Se verifica a quien se le agrega el punto
           if (enTurno == 1)
           {
               // Indica quien se rindio
               cout << "Se ha rendido " << jug_1.nombre << endl;

               // Se incrementa el Contador del otro jugador
               puntos_juga_2++;

               // Verifica los puntos
               if (puntos_juga_2==2)
               {
                   cout << jug_2.nombre << " Ha vencido !!" << endl;
               }
               else
               {
                   // Se incrementa el Round
                   roundJugandose++;
                   cout << "Se inicia un nuevo round " << roundJugandose << endl;
                   fnBosque();
                   cout << "Se ha generado el Bosque" << endl;
               }
           }
           else
           {
               // Indica quien se rindio
               cout << "Se ha rendido " << jug_1.nombre << endl;

               // Se incrementa el Contador del otro jugador
               puntos_juga_1++;

               // Verifica los puntos
               if (puntos_juga_1==2)
               {
                   cout << jug_1.nombre << " Ha vencido !!" << endl;
               }
               else
               {
                   // Se incrementa el Round
                   roundJugandose++;
                   cout << "Se inicia un nuevo round " << roundJugandose << endl;
                   fnBosque();
                   cout << "Se ha generado el Bosque" << endl;
               }
           }
        }
        else
        // Verifica si es movimiento
        if (jugada == MOV_ARRIBA || jugada == MOV_ABAJO ||
            jugada == MOV_DERECHA || jugada == MOV_IZQUIERDA)
        {
            // Verifica si se pudo mover el Jugador
            if (movimiento(jugada))
                // Cambia el Turno
                if (enTurno==1)                            
                    enTurno = 2;            
                else
                    enTurno = 1;                    
        }
        else
        if (jugada == FLECHA_ABAJO  || jugada == FLECHA_DERECHA ||
            jugada == FLECHA_ARRIBA || jugada == FLECHA_IZQUIERDA)
        {
            // Se inicializa con false
            impacto = false;

            // Varifica que flecha es
            switch (jugada)
            {
                case FLECHA_ARRIBA:
                     if (fnDispararArriba())
                     {
                         // La Flecha Impacto
                         impacto = true;                         
                     }
                     break;
                case FLECHA_ABAJO:   
                     if (fnDispararAbajo())
                     {
                         // La Flecha Impacto
                         impacto = true;

                     }             
                    break;       
                case FLECHA_IZQUIERDA:  
                     if (fnDispararIzquierda())
                     {
                         // La Flecha Impacto
                         impacto = true;
                     }              
                    break; 
                case FLECHA_DERECHA:        
                     if (fnDispararDerecha())
                     {
                         // La Flecha Impacto
                         impacto = true;
                     }        
                    break;                          
            }

            // Verifica impacto
            if (impacto)
            {
                if (enTurno==1)
                {
                   // Se incrementa el Contador del otro jugador
                   puntos_juga_1++;

                   // Verifica los puntos
                   if (puntos_juga_1==2)
                   {
                       cout << jug_1.nombre << " Ha vencido !!" << endl;
                   }
                   else
                   {
                       // Se incrementa el Round
                       roundJugandose++;
                       cout << "Se inicia un nuevo round " << roundJugandose << endl;
                       fnBosque();
                       cout << "Se ha generado el Bosque" << endl;
                   }
                }
                else
                {
                    // Se incrementa el Contador del otro jugador
                    puntos_juga_2++;

                    // Verifica los puntos
                    if (puntos_juga_2==2)
                    {
                        cout << jug_2.nombre << " Ha vencido !!" << endl;
                    }
                    else
                    {
                        // Se incrementa el Round
                        roundJugandose++;
                        cout << "Se inicia un nuevo round " << roundJugandose << endl;
                        fnBosque();
                        cout << "Se ha generado el Bosque" << endl;
                    }
                }
            }  
            
            // Cambio de Turno
            if (enTurno==1)
               enTurno=2;
            else
               enTurno=1;  
        }
        else
        {
            // Mensaje de Jugada Incorrecta
            cout << "Jugada Incorrecta ... " << endl;
            fnEsperar();
        }               
    }
} 
 
 
// funcion para imprimir la Matriz 
void imprimir_matriz () 
{   
    // Mensaje
    cout << "Tablero " << endl;

    // Deja 2 espacios
    cout << "  ";

    // Ciclo para imprimir las letras de la Columnas
    for (int columnas = 0; columnas < dim; columnas++)    
        cout << char(columnas+65) << " ";

    // Cambia de linea al fina
    cout << endl;    

    // Ciclo para las filas
    for (int fila = 0; fila < dim; fila ++) 
    {
        // Imprime la identificacion del Renglon
        cout << fila+1 << " ";

        // Ciclo para las filas
        for (int columna = 0; columna < dim; columna++) 
        {
            // Imprime el contenido del bosque
            cout << bosque[fila][columna] << " ";
        }

        // Cambia de Linea
        cout << endl;
    }    

    // Deja una linea
    cout << endl;
}

// función para disparar flecha arriba
int fnDispararArriba()
{
    // Variable para renglon y columna
    int renglon;
    int columna;

    // Obtiene las coordenadas de acuerdo al jugador en Turno
    if (enTurno==1)
    {
        renglon = jug_1.fil;
        columna = jug_1.col;
    }
    else
    {
        renglon = jug_2.fil;
        columna = jug_2.col;
    }

    // Resultado 
    int resultado = FALSE;

    // fuera del Tablero
    int flechaSalioDelTablero = FALSE;

    // Avance de la flecha
    int avanceFlecha = 0;
    
    // Ciclo para buscar hacia arriba
    while (avanceFlecha < 5)
    {
        // Incrementa el Avance de la Flecha
        avanceFlecha++;

        // decrementa el renglon
        renglon--;

        // Verifica que no haya salido del tablero
        if (renglon < 0)
        {
           // Salio del Tablero
           flechaSalioDelTablero = TRUE;

           // Cambia el Resultado
           resultado = FALSE;

           // Sale del Ciclo
           break;
        }
        else
        // Verifica si hay un árbol
        if (ocupado_arbol(renglon,columna))
        {
           // Cambia el Resultado
           resultado = FALSE;

           // Mensaje
           cout << "La Flecha se ha impactado con un Arbol" << endl;
           fnEsperar();

           // Sale
           break;
        }
        else
        if (fnHayJugador(renglon,columna))        
        {
            // Cambia el Resultado
            resultado = TRUE;

            // Sale
            break;
        }
    }

    // Verifica si ha alcanzado oponente
    if (resultado)
    {
        // Mensaje de Exito
        cout << "Exito ! La Flecha ha alcanzado al oponente" << endl;
        fnEsperar();
    }
    else   
    // Verifica si la flecha sale del tablero
    if (flechaSalioDelTablero)
    {
       cout  << "La Flecha salio del Tablero sin encontrar oponente" << endl;
       fnEsperar();
    }
    else
    // Verifica
    if (avanceFlecha == 5)
    {
        // Mensaje
        cout << "La Flecha alcanzo su distancia sin encontrar oponente";
        fnEsperar();
    }
    // Devuelve el resultado
    return resultado;   
}

// función dispara flecha hacia Derecha
int fnDispararDerecha()
{
    // Variable para renglon y columna
    int renglon;
    int columna;

    // Obtiene las coordenadas de acuerdo al jugador en Turno
    if (enTurno==1)
    {
        renglon = jug_1.fil;
        columna = jug_1.col;
    }
    else
    {
        renglon = jug_2.fil;
        columna = jug_2.col;
    }

    // Resultado 
    int resultado = FALSE;

    // fuera del Tablero
    int flechaSalioDelTablero = FALSE;

    // Avance de la flecha
    int avanceFlecha = 0;
    
    // Ciclo para buscar hacia arriba
    while (avanceFlecha < 5)
    {
        // Incrementa el Avance de la Flecha
        avanceFlecha++;

        // incrementa la columna
        columna++;

        // Verifica que no haya salido del tablero
        if (columna == dim)
        {
           // Salio del Tablero
           flechaSalioDelTablero = TRUE;

           // Cambia el Resultado
           resultado = FALSE;

           // Sale del Ciclo
           break;
        }

        // Verifica si hay un árbol
        if (ocupado_arbol(renglon,columna))
        {
           // Cambia el Resultado
           resultado = FALSE;

           // Mensaje
           cout << "La Flecha se ha impactado con un Arbol";
           fnEsperar();

           // Sale
           break;
        }
        else
        if (fnHayJugador(renglon,columna))        
        {
            // Cambia el Resultado
            resultado = TRUE;

            // Sale
            break;
        }
    }

    // Verifica si ha alcanzado oponente
    if (resultado)
    {
        // Mensaje
        cout << "! Exito ! La Flecha ha alcanzado al oponente";
        fnEsperar();
    }
    else   
    // Verifica si la flecha sale del tablero
    if (flechaSalioDelTablero)
    {
        // MEnsaje
        cout << "La Flecha salio del Tablero sin encontrar oponente";
        fnEsperar();
    }
    else
    // Verifica
    if (avanceFlecha == 5)
    {
        // Mensaje
        cout << "La Flecha alcanzo su distancia sin encontrar oponente";
    }
    // Devuelve el resultado
    return resultado;   
}


// función para disparar flecha abajo
int fnDispararAbajo()
{
    // Variable para renglon y columna
    int renglon;
    int columna;

    // Obtiene las coordenadas de acuerdo al jugador en Turno
    if (enTurno==1)
    {
        renglon = jug_1.fil;
        columna = jug_1.col;
    }
    else
    {
        renglon = jug_2.fil;
        columna = jug_2.col;
    }

    // Resultado 
    int resultado = FALSE;

    // fuera del Tablero
    int flechaSalioDelTablero = FALSE;

    // Avance de la flecha
    int avanceFlecha = 0;
    
    // Ciclo para buscar hacia arriba
    while (avanceFlecha < 5)
    {
        // Incrementa el Avance de la Flecha
        avanceFlecha++;

        // incrementa el renglon
        renglon++;

        // Verifica que no haya salido del tablero
        if (renglon == dim)
        {
           // Salio del Tablero
           flechaSalioDelTablero = TRUE;

           // Cambia el Resultado
           resultado = FALSE;

           // Sale del Ciclo
           break;
        }

        // Verifica si hay un árbol
        if (ocupado_arbol(renglon,columna))
        {
           // Cambia el Resultado
           resultado = FALSE;

           // Mensaje
           cout << "La Flecha se ha impactado con un Arbol";
           fnEsperar();

           // Sale
           break;
        }
        else
        if (fnHayJugador(renglon,columna))        
        {
            // Cambia el Resultado
            resultado = TRUE;
            
            // Sale
            break;
        }
    }

    // Verifica si ha alcanzado oponente
    if (resultado)
    {
        // Mensaje
        cout << "! Exito ! La Flecha ha alcanzado al oponente";
        fnEsperar();
    }
    else   
    // Verifica si la flecha sale del tablero
    if (flechaSalioDelTablero)
    {
        // Mensaje
        cout << "La Flecha salio del Tablero sin encontrar oponente";
        fnEsperar();
    }
    else
    // Verifica
    if (avanceFlecha == 5)
    {
       cout << "La Flecha alcanzo su distancia sin encontrar oponente";
       fnEsperar();
    }

    // Devuelve el resultado
    return resultado;   
}

// función dispara flecha hacia Izquierda
int fnDispararIzquierda()
{
    // Variable para renglon y columna
    int renglon;
    int columna;

    // Obtiene las coordenadas de acuerdo al jugador en Turno
    if (enTurno==1)
    {
        renglon = jug_1.fil;
        columna = jug_1.col;
    }
    else
    {
        renglon = jug_2.fil;
        columna = jug_2.col;
    }

    // Resultado 
    int resultado = FALSE;

    // fuera del Tablero
    int flechaSalioDelTablero = FALSE;

    // Avance de la flecha
    int avanceFlecha = 0;
    
    // Ciclo para buscar hacia arriba
    while (avanceFlecha < 5)
    {
        // Incrementa el Avance de la Flecha
        avanceFlecha++;

        // decrementa la columna
        columna--;

        // Verifica que no haya salido del tablero
        if (columna < 0)
        {
           // Salio del Tablero
           flechaSalioDelTablero = TRUE;

           // Cambia el Resultado
           resultado = FALSE;

           // Sale del Ciclo
           break;
        }

        // Verifica si hay un árbol
        if (ocupado_arbol(renglon,columna))
        {
           // Cambia el Resultado
           resultado = FALSE;

           // Mensaje
           cout << "La Flecha se ha impactado con un Arbol";

           // Sale
           break;
        }
        else
        if (fnHayJugador(renglon,columna))        
        {
            // Sale
            break;
        }
    }

    // Verifica si ha alcanzado oponente
    if (resultado)
    {
        // Mensaje
        cout << "! Exito ! La Flecha ha alcanzado al oponente";
        fnEsperar();
    }
    else   
    // Verifica si la flecha sale del tablero
    if (flechaSalioDelTablero)
    {
        // Mensaje
        cout << "La Flecha salio del Tablero sin encontrar oponente";
        fnEsperar();
    }
    else
    // Verifica
    if (avanceFlecha == 5)
    {
        // Mensaje
        cout << "La Flecha alcanzo su distancia sin encontrar oponente";
    }

    // Devuelve el resultado
    return resultado;   
}

int fnHayJugador(int ren, int col)
{
    // Verifica si hay Jugador 1
    if (bosque[ren][col]=='1' || bosque[ren][col]=='2')    
       return TRUE;
    else
       return FALSE;           
}
