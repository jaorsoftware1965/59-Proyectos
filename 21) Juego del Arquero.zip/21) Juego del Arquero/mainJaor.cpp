// --------------------------------------
// El Juego del Arquero Version Simple
// JAOR
// --------------------------------------

// Librerias
#include <conio.h>
#include <limits>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <iostream> 
#include <stdio.h> 
#include <string.h> 

// Constantes
#define MAX_DIM          26    // Maxima Longitud del Tablero
#define MIN_DIM           6    // Minima Longitud del Tablero
#define FICHA_JUG1       '1'   // Ficha del Jugador 1
#define FICHA_JUG2       '2'   // Ficha del Jugador 2
#define FICHA_ARBOL      'X'   // Ficha del Arbol
#define LIMPIAR_PANTALLA "cls" // Comando para Limpiar Pantalla
#define ALCANCE_FLECHA    5    // Alcance de la Flecha
#define CODIGO_ASCII_A    65   // Codígo Ascii de la Letra A

// Teclas de Juego
#define SALIR            'q'
#define RENDIRSE         'r'
#define MOV_ARRIBA       'w'
#define MOV_ABAJO        's'
#define MOV_DERECHA      'd'
#define MOV_IZQUIERDA    'a'
#define FLECHA_ARRIBA    'y'
#define FLECHA_ABAJO     'h'
#define FLECHA_DERECHA   'j'
#define FLECHA_IZQUIERDA 'g'


// Definimos el Espacio de Nombres
using namespace std;

// Variables globales
int  gDimension;                  // gDimension del Juego
char gTablero[MAX_DIM][MAX_DIM];  // Tablero
int  gEnTurno;                    // Que jugador está en turno
int  gJugadorInicia;              // Jugador que Inicia


// Estructura para los Jugadores
struct jugador 
{  
    // Nombre del Jugador
    string nombre;    
    
    // Posición actual en el Tablero
    int fil;
    int col;

}gJugador1,gJugador2; // Variables para los Jugadores

// Prototipo de Funciones
void fnLimpiarPantalla();
void fnEsperar();
int  fnNumeroAleatorioGenerar();
void fnMenuJugador(int roundJugandose);
void fnMenuPartida();
void fnTableroImprimir();
void fnTableroCrear();
int  fnJugadorMover(char tecla);
bool fnPosicionValida(int fila, int columna);
bool fnPosicionTieneArbol(int fila, int columna);
bool fnPosicionLibre(int fila, int columna);
void fnJuegoIniciar();
int  fnDispararArriba();
int  fnDispararDerecha();
int  fnDispararAbajo();
int  fnDispararIzquierda();
bool fnPosicionTieneJugador(int ren, int col);

// Función Principal
int main()
{
    // Inicializa la Generación de Aleatorios
    srand(time(NULL));

    // Limpia la Pantalla
    fnLimpiarPantalla();

    // Despliega el Menu de la Partida
    fnMenuPartida();

    // Genera el Tablero
    fnTableroCrear();

    // Iniciar el Juego
    fnJuegoIniciar();        

    // Fin del Programa         
    return 0;     
}

// Función para Limpiar la Pantalla 
void fnLimpiarPantalla()
{
   // Ejecuta el Comando
   system (LIMPIAR_PANTALLA);
}

    
// Despliega el Menu Iiicial    
void fnMenuInicial() 
{   
    // Menu Inicial  para ingresar a nueva partida o salir del juego//
    cout << "Bienvenido al menu de Partidas"<< endl<<endl;
    cout << "Ingrese la opcion que desee:" << endl;
    cout << "1. Ingresar a la nueva partida." << endl;
    cout << "0. Salir" << endl;
} 

// Generar Numero Aleatorio
int fnNumeroAleatorioGenerar()
{
    // Variable de resultado
    int resultado;   

    // Genera el Numero aleatorio
    resultado = rand() % gDimension; 

    // Devuelve el Numero
    return resultado;
}

 // función para ver quien inicia
 void fnMenuPartida()
 {
    // ingresar nombres de los jugadores y quien desea comenzar//
    // int inicia; no es necesaria por gEnTurno
    cout << "Ingrese el nombre del jugador 1: \n";
    cin  >> gJugador1.nombre;
    cout << "Ingrese el nombre del jugador 2: \n";
    cin  >> gJugador2.nombre;

    // Limpia la Pantalla
    fnLimpiarPantalla();
    
    // Ciclo para saber quien inicia
    do
    {
        // Pregunta quien Comienza
        cout << "Quien comienza:" << endl;
        cout << "1-->" <<  gJugador1.nombre << endl;
        cout << "2-->" <<  gJugador2.nombre << endl;

        // Lee quien comienza
        cin >> gJugadorInicia;

        // Lo coloca en Turno
        gEnTurno = gJugadorInicia;

        // Limpia la Pantalla
        fnLimpiarPantalla();

        // Verifica jugador
        switch(gEnTurno)
        {
            case 1:
                 cout << "Comienza jugando " << gJugador1.nombre << endl;
                 break;
            case 2:                
                 cout << "Comienza jugando " << gJugador2.nombre << endl;
                 break;
            default:
                 cout<<"opcion incorrecta"<<endl;
        }
    }
    while(gEnTurno!=1 && gEnTurno != 2);
  }

// Función para crear el Tablero, ubicar jugadores y arboles
void fnTableroCrear()
{   
    // Ciclo para crear el Tablero
    do
    {
        // Mensaje
        cout << "Ingrese la Dimension que desea tenga el Tablero entre ";
        cout << MIN_DIM << " y " << MAX_DIM << endl;
        
        // Lee la dimensión
        cin  >> gDimension;
        
        // Limpia la Pantalla
        fnLimpiarPantalla();
    }
    while ( (gDimension>MAX_DIM)||
            (gDimension<MIN_DIM) );

    // Ciclo para inicializar el Tablero
    for (int fila = 0; fila < gDimension; fila ++) 
    {
        for (int columna = 0; columna < gDimension; columna++) 
        {
            // Coloca espacios en toda la matriz
            gTablero[fila][columna] = ' '; 
        }
    }
    

    // Ubicamos los Jugadores
    // ubicamos el jugador 1
    gTablero[gDimension-1][0] = FICHA_JUG1; 
    // ubicamos el jugador 2
    gTablero[0][gDimension-1] = FICHA_JUG2;

    // Colocamos las posiciones de los jugadores en sus
    // Variables
    gJugador1.fil = gDimension-1;
    gJugador1.col = 0;
    gJugador2.fil = 0;
    gJugador2.col = gDimension-1;

    // Calcula el 15% arboles a generar
    int aprox_arbol = (((gDimension*gDimension)*15)/ 100); 

    // Ciclo para generar los arboles
    for (int cuentaArboles = 0; cuentaArboles <aprox_arbol; cuentaArboles++)
    {
        // Ciclo
        while (true)
        {
            // Obtiene Aleatorios para fila y columna
            int fila    = fnNumeroAleatorioGenerar();
            int columna = fnNumeroAleatorioGenerar();

            // Verifica si está desocupado
            if (gTablero[fila][columna]==' ')
            {
                // Inserta el Arbol
                gTablero[fila][columna]= FICHA_ARBOL;

                // Sale del Ciclo 
                break;
            }            
        } 
    }
 }

 // Función para el Menu del Jugador   
 void fnMenuJugador(int roundJugandose)
 {    
    // Peticion e informacion 
    cout << "Jugando el Round :" << roundJugandose << endl;
    cout << "Ingrese la opcion que desee:" << endl;
    cout << "q---salir"<<endl;
    cout << "r---rendirse"<<endl;
    cout << "w---moverse hacia arriba"<<endl;
    cout << "s---moverse hacia abajo"<<endl;
    cout << "d---moverse hacia la derecha"<<endl;
    cout << "a---moverse hacia la izquierda"<<endl;
    cout << "y---flecha hacia arriba"<<endl;
    cout << "h---flecha hacia abajo"<<endl;
    cout << "j---flecha hacia la derecha"<<endl;
    cout << "g---flecha hacia la izquierda"<<endl;    
}

 // Función para fnEsperar 
 void fnEsperar() 
 { 
    // Mensaje
    cout << "\n[ PRESIONE ENTER PARA CONTINUAR ]";
    fflush(stdin);
    
    // Espera a que de enter
    cin.ignore (100000, '\n' );
    
    // Limpia la Pantalla
    fnLimpiarPantalla();
}
    
 

// Función que mueve al jugador      
int fnJugadorMover (char opcion)
{   
    // Variable de Resultado
    int resultado = false;

    // Variables para el fnJugadorMover
    int  fila;
    int  columna;
    char ficha;

    // Verifica quien es el jugador en turno
    // para obtener coordenadas
    if (gEnTurno==1)  
    {
       // Obtiene los datos del primer jugador
       fila    = gJugador1.fil;
       columna = gJugador1.col;
       ficha   = FICHA_JUG1;
    }
    else
    {
       // Obtiene los datos del segundo jugador
       fila    = gJugador2.fil;
       columna = gJugador2.col;
       ficha   = FICHA_JUG2;
    }

    // Verifica opción
    switch (opcion)
    {
        case MOV_ARRIBA: 
             // Decrementa la Fila porque va hacia arriba
             fila = fila - 1;
             if (fnPosicionValida(fila,columna) && 
                 fnPosicionLibre(fila,columna))
             {
                 // Mueve el Jugador
                 // Elimina donde esta actualmente
                 gTablero[fila+1][columna]=' '; 
                 
                 // Lo mueve a la nueva posición
                 gTablero[fila][columna]=ficha; 

                 // Mensaje
                 cout << "Se ha movido el Jugador " << ficha << " hacia arriba."  << endl;

                 // ACtualiza resultado
                 resultado = true;
             }
             break;

        case MOV_ABAJO: 
             // Incrementa la Fila porque va hacia abajo
             fila = fila + 1;
             if (fnPosicionValida(fila,columna) && 
                 fnPosicionLibre(fila,columna))
             {
                 // Mueve el Jugador
                 // Elimina donde esta actualmente
                 gTablero[fila-1][columna]=' '; 
                 
                 // Lo mueve a la nueva posición
                 gTablero[fila][columna]=ficha; 

                 // Mensaje
                 cout << "Se ha movido el Jugador " << ficha << " hacia abajo." << endl;

                 // Actualiza Resultado
                 resultado = true;
             }     
             break;
        case MOV_DERECHA: 
             // Incrementa la Columna porque va hacia derecha
             columna = columna + 1;
             if (fnPosicionValida(fila,columna) && 
                 fnPosicionLibre(fila,columna))
             {
                 // Mueve el Jugador
                 // Elimina donde esta actualmente
                 gTablero[fila][columna-1] = ' '; 
                 
                 // Lo mueve a la nueva posición
                 gTablero[fila][columna] = ficha; 

                 // Mensaje
                 cout << "Se ha movido el Jugador " << ficha << " hacia la derecha." << endl;

                 // Actualiza Resultado
                 resultado = true;
             }
             break;
        case MOV_IZQUIERDA: 
             // Decrementa la Columna porque va hacia izquierda
             columna = columna - 1;
             if (fnPosicionValida(fila,columna) && 
                 fnPosicionLibre(fila,columna))
             {
                 // Mueve el Jugador
                 // Elimina donde esta actualmente
                 gTablero[fila][columna+1] = ' '; 
                 
                 // Lo mueve a la nueva posición
                 gTablero[fila][columna] = ficha; 

                 // Mensaje
                 cout << "Se ha movido el Jugador " << ficha << " hacia la izquierda." << endl;

                 // Actualiza Resultado
                 resultado = true;
             } 
             break;                       
    }

    // Verifico si actualizo posiciones
    if (resultado)
       if (gEnTurno==1)
       {
          // Actualizo J1
          gJugador1.fil = fila;
          gJugador1.col = columna;
       }
       else
       {
          // Actualizo J2
          gJugador2.fil = fila;
          gJugador2.col = columna;
       }

    // Devuelve el resultado
    return resultado;
}  

// Función para controlar que no se salga del Tablero
bool fnPosicionValida (int fila, int columna)
{ 
    //para que el jugador no se salga del Tablero
    if (fila    < 0 || fila    == gDimension || 
        columna < 0 || columna == gDimension)
    {
       // No es valido el Movimiento
       cout << "Movimiento fuera del Tablero" << endl;
       fnEsperar();
       return false;
    }
    else 
       // Si es valido
       return true;
}

// Verifica si hay un arbol
bool fnPosicionTieneArbol(int fila, int columna) 
{
    // Verifica si hay un árbol
    if (gTablero [fila][columna]==FICHA_ARBOL)
    {
        // Si hay un arbol
        return true;
    }
    else
        // NO hay un arbol
        return false; 
}

// Verifica si la posición está libre
bool  fnPosicionLibre(int fila, int columna)
{
    // Verifica posición libre
    if (gTablero[fila][columna]==' ')
       // Si está libre
       return true;
    else
    {
        // Mensaje
        cout << "La posicion esta ocupada " <<  endl;
        fnEsperar();
        // No está libre
        return false;   
    }
}
   
// Se inicia el Juego
void fnJuegoIniciar ()
{      
    // Variable para Controlar el Juego
    int  roundJugandose=1;
    char ultima_jugada=' ';
    int  puntos_juga_1 =  0;
    int  puntos_juga_2 =  0;    
    char jugada; 
    bool impacto;
    
    // Ciclo que controla el Juego        
    while (puntos_juga_1 < 2 && 
           puntos_juga_2 < 2)
    {
        // Imprime la Matriz
        fnTableroImprimir();           

        // Despliega el Menu del Jugador
        fnMenuJugador(roundJugandose);
        
        // Despliega la ultima jugada
        cout << "Ultima Jugada : " << ultima_jugada << endl; 

        // Despliega quien Juega
        if (gEnTurno==1)            
        {
            // Mensaje
            cout << "Jugando       : " << gJugador1.nombre << "[" << FICHA_JUG1 << "]" << endl;             
            cout << "Puntos        : " << puntos_juga_1 << endl;           
        }
        else
        {
            // Mensaje 
            cout << "Jugando " << gJugador2.nombre <<  "[" << FICHA_JUG2 << "]" <<endl;
            cout << "Puntos :" << puntos_juga_2 << endl;           
        }            
        // Lee la opcion
        cin >> jugada;

        // Verifica si es salir
        if (jugada == SALIR)
        {
            // Genera los arboles de Nuevo
            cout << "Has salido de la Partida " << endl;
            cout << "Se inicia de nuevo el round :" << roundJugandose << endl;
            fnTableroCrear();
            gEnTurno = gJugadorInicia;
            ultima_jugada=' ';
            cout << "Se ha generado el Tablero" << endl;

            // Se coloca el jugador en Turno
            gEnTurno = gJugadorInicia;

        }
        else
        if (jugada == RENDIRSE)
        {
           // Se verifica a quien se le agrega el punto
           if (gEnTurno == 1)
           {
               // Indica quien se rindio
               cout << "Se ha rendido " << gJugador1.nombre << endl;

               // Se incrementa el Contador del otro jugador
               puntos_juga_2++;

               // Verifica los puntos
               if (puntos_juga_2==2)
               {
                   cout << gJugador2.nombre << " Ha vencido !!" << endl;
               }
               else
               {
                   // Se incrementa el Round
                   roundJugandose++;
                   cout << "Se inicia un nuevo round :" << roundJugandose << endl;
                   fnTableroCrear();
                   gEnTurno = gJugadorInicia;
                   ultima_jugada=' ';
                   cout << "Se ha generado el Tablero" << endl;
               }
           }
           else
           {
               // Indica quien se rindio
               cout << "Se ha rendido " << gJugador2.nombre << endl;

               // Se incrementa el Contador del otro jugador
               puntos_juga_1++;

               // Verifica los puntos
               if (puntos_juga_1==2)
               {
                   cout << gJugador1.nombre << " Ha vencido !!" << endl;
               }
               else
               {
                   // Se incrementa el Round
                   roundJugandose++;
                   cout << "Se inicia un nuevo round :" << roundJugandose << endl;
                   fnTableroCrear();
                   gEnTurno = gJugadorInicia;
                   ultima_jugada=' ';
                   cout << "Se ha generado el Tablero" << endl;
               }
           }
        }
        else
        // Verifica si es fnJugadorMover
        if (jugada == MOV_ARRIBA || jugada == MOV_ABAJO ||
            jugada == MOV_DERECHA || jugada == MOV_IZQUIERDA)
        {
            // Verifica si se pudo mover el Jugador
            if (fnJugadorMover(jugada))
                // Cambia el Turno
                if (gEnTurno==1)                            
                    gEnTurno = 2;            
                else
                    gEnTurno = 1;                    
        }
        else
        if (jugada == FLECHA_ABAJO  || jugada == FLECHA_DERECHA ||
            jugada == FLECHA_ARRIBA || jugada == FLECHA_IZQUIERDA)
        {
            // Se inicializa con false
            impacto = false;

            // Varifica que flecha es
            switch (jugada)
            {
                case FLECHA_ARRIBA:
                     if (fnDispararArriba())
                     {
                         // La Flecha Impacto
                         impacto = true;                         
                     }
                     break;
                case FLECHA_ABAJO:   
                     if (fnDispararAbajo())
                     {
                         // La Flecha Impacto
                         impacto = true;

                     }             
                    break;       
                case FLECHA_IZQUIERDA:  
                     if (fnDispararIzquierda())
                     {
                         // La Flecha Impacto
                         impacto = true;
                     }              
                    break; 
                case FLECHA_DERECHA:        
                     if (fnDispararDerecha())
                     {
                         // La Flecha Impacto
                         impacto = true;
                     }        
                    break;                          
            }

            // Verifica impacto
            if (impacto)
            {
                if (gEnTurno==1)
                {
                   // Se incrementa el Contador del otro jugador
                   puntos_juga_1++;

                   // Verifica los puntos
                   if (puntos_juga_1==2)
                   {
                       cout << gJugador1.nombre << " Ha vencido !!" << endl;
                   }
                   else
                   {
                       // Se incrementa el Round
                       roundJugandose++;
                       cout << "Se inicia un nuevo round :" << roundJugandose << endl;
                       fnTableroCrear();
                       gEnTurno = gJugadorInicia;
                       ultima_jugada=' ';
                       cout << "Se ha generado el Tablero" << endl;
                   }
                }
                else
                {
                    // Se incrementa el Contador del otro jugador
                    puntos_juga_2++;

                    // Verifica los puntos
                    if (puntos_juga_2==2)
                    {
                        cout << gJugador2.nombre << " Ha vencido !!" << endl;
                    }
                    else
                    {
                        // Se incrementa el Round
                        roundJugandose++;
                        cout << "Se inicia un nuevo round :" << roundJugandose << endl;
                        fnTableroCrear();
                        gEnTurno = gJugadorInicia;
                        ultima_jugada=' ';
                        // Inicializa ultima jugada
                        ultima_jugada=' ';
                        cout << "Se ha generado el Tablero" << endl;
                    }
                }
            }  
            
            // Cambio de Turno
            if (gEnTurno==1)
               gEnTurno=2;
            else
               gEnTurno=1;  
        }
        else
        {
            // Mensaje de Jugada Incorrecta
            cout << "Jugada Incorrecta ... " << endl;
            fnEsperar();
        }               

        // Obtiene la ultima jugada
        ultima_jugada = jugada;
    }
} 
 
 
// funcion para imprimir la Matriz 
void fnTableroImprimir () 
{   
    // Mensaje
    cout << "Tablero " << endl;

    // Deja 2 espacios
    cout << "  ";

    // Ciclo para imprimir las letras de la Columnas
    for (int columnas = 0; columnas < gDimension; columnas++)    
        cout << char(columnas+CODIGO_ASCII_A) << " ";

    // Cambia de linea al fina
    cout << endl;    

    // Ciclo para las filas
    for (int fila = 0; fila < gDimension; fila ++) 
    {
        // Imprime la identificacion del Renglon
        cout << fila+1 << " ";

        // Ciclo para las filas
        for (int columna = 0; columna < gDimension; columna++) 
        {
            // Imprime el contenido del Tablero
            cout << gTablero[fila][columna] << " ";
        }

        // Cambia de Linea
        cout << endl;
    }    

    // Deja una linea
    cout << endl;
}

// función para disparar flecha arriba
int fnDispararArriba()
{
    // Variable para renglon y columna
    int renglon;
    int columna;

    // Obtiene las coordenadas de acuerdo al jugador en Turno
    if (gEnTurno==1)
    {
        renglon = gJugador1.fil;
        columna = gJugador1.col;
    }
    else
    {
        renglon = gJugador2.fil;
        columna = gJugador2.col;
    }

    // Resultado 
    int resultado = false;

    // fuera del Tablero
    int flechaSalioDelTablero = false;

    // Avance de la flecha
    int avanceFlecha = 0;
    
    // Ciclo para buscar hacia arriba
    while (avanceFlecha < ALCANCE_FLECHA)
    {
        // Incrementa el Avance de la Flecha
        avanceFlecha++;

        // decrementa el renglon
        renglon--;

        // Verifica que no haya salido del Tablero
        if (renglon < 0)
        {
           // Salio del Tablero
           flechaSalioDelTablero = true;

           // Cambia el Resultado
           resultado = false;

           // Sale del Ciclo
           break;
        }
        else
        // Verifica si hay un árbol
        if (fnPosicionTieneArbol(renglon,columna))
        {
           // Cambia el Resultado
           resultado = false;

           // Mensaje
           cout << "La Flecha se ha impactado con un Arbol" << endl;
           fnEsperar();

           // Sale
           break;
        }
        else
        if (fnPosicionTieneJugador(renglon,columna))        
        {
            // Cambia el Resultado
            resultado = true;

            // Sale
            break;
        }
    }

    // Verifica si ha alcanzado oponente
    if (resultado)
    {
        // Mensaje de Exito
        cout << "Exito ! La Flecha ha alcanzado al oponente" << endl;
        fnEsperar();
    }
    else   
    // Verifica si la flecha sale del Tablero
    if (flechaSalioDelTablero)
    {
       cout  << "La Flecha salio del Tablero sin encontrar oponente" << endl;
       fnEsperar();
    }
    else
    // Verifica
    if (avanceFlecha == ALCANCE_FLECHA)
    {
        // Mensaje
        cout << "La Flecha alcanzo su distancia sin encontrar oponente";
        fnEsperar();
    }
    // Devuelve el resultado
    return resultado;   
}

// función dispara flecha hacia Derecha
int fnDispararDerecha()
{
    // Variable para renglon y columna
    int renglon;
    int columna;

    // Obtiene las coordenadas de acuerdo al jugador en Turno
    if (gEnTurno==1)
    {
        renglon = gJugador1.fil;
        columna = gJugador1.col;
    }
    else
    {
        renglon = gJugador2.fil;
        columna = gJugador2.col;
    }

    // Resultado 
    int resultado = false;

    // fuera del Tablero
    int flechaSalioDelTablero = false;

    // Avance de la flecha
    int avanceFlecha = 0;
    
    // Ciclo para buscar hacia arriba
    while (avanceFlecha < ALCANCE_FLECHA)
    {
        // Incrementa el Avance de la Flecha
        avanceFlecha++;

        // incrementa la columna
        columna++;

        // Verifica que no haya salido del Tablero
        if (columna == gDimension)
        {
           // Salio del Tablero
           flechaSalioDelTablero = true;

           // Cambia el Resultado
           resultado = false;

           // Sale del Ciclo
           break;
        }

        // Verifica si hay un árbol
        if (fnPosicionTieneArbol(renglon,columna))
        {
           // Cambia el Resultado
           resultado = false;

           // Mensaje
           cout << "La Flecha se ha impactado con un Arbol";
           fnEsperar();

           // Sale
           break;
        }
        else
        if (fnPosicionTieneJugador(renglon,columna))        
        {
            // Cambia el Resultado
            resultado = true;

            // Sale
            break;
        }
    }

    // Verifica si ha alcanzado oponente
    if (resultado)
    {
        // Mensaje
        cout << "! Exito ! La Flecha ha alcanzado al oponente";
        fnEsperar();
    }
    else   
    // Verifica si la flecha sale del Tablero
    if (flechaSalioDelTablero)
    {
        // MEnsaje
        cout << "La Flecha salio del Tablero sin encontrar oponente";
        fnEsperar();
    }
    else
    // Verifica
    if (avanceFlecha == ALCANCE_FLECHA)
    {
        // Mensaje
        cout << "La Flecha alcanzo su distancia sin encontrar oponente";
    }
    // Devuelve el resultado
    return resultado;   
}


// función para disparar flecha abajo
int fnDispararAbajo()
{
    // Variable para renglon y columna
    int renglon;
    int columna;

    // Obtiene las coordenadas de acuerdo al jugador en Turno
    if (gEnTurno==1)
    {
        renglon = gJugador1.fil;
        columna = gJugador1.col;
    }
    else
    {
        renglon = gJugador2.fil;
        columna = gJugador2.col;
    }

    // Resultado 
    int resultado = false;

    // fuera del Tablero
    int flechaSalioDelTablero = false;

    // Avance de la flecha
    int avanceFlecha = 0;
    
    // Ciclo para buscar hacia arriba
    while (avanceFlecha < ALCANCE_FLECHA)
    {
        // Incrementa el Avance de la Flecha
        avanceFlecha++;

        // incrementa el renglon
        renglon++;

        // Verifica que no haya salido del Tablero
        if (renglon == gDimension)
        {
           // Salio del Tablero
           flechaSalioDelTablero = true;

           // Cambia el Resultado
           resultado = false;

           // Sale del Ciclo
           break;
        }

        // Verifica si hay un árbol
        if (fnPosicionTieneArbol(renglon,columna))
        {
           // Cambia el Resultado
           resultado = false;

           // Mensaje
           cout << "La Flecha se ha impactado con un Arbol";
           fnEsperar();

           // Sale
           break;
        }
        else
        if (fnPosicionTieneJugador(renglon,columna))        
        {
            // Cambia el Resultado
            resultado = true;
            
            // Sale
            break;
        }
    }

    // Verifica si ha alcanzado oponente
    if (resultado)
    {
        // Mensaje
        cout << "! Exito ! La Flecha ha alcanzado al oponente";
        fnEsperar();
    }
    else   
    // Verifica si la flecha sale del Tablero
    if (flechaSalioDelTablero)
    {
        // Mensaje
        cout << "La Flecha salio del Tablero sin encontrar oponente";
        fnEsperar();
    }
    else
    // Verifica
    if (avanceFlecha == ALCANCE_FLECHA)
    {
       cout << "La Flecha alcanzo su distancia sin encontrar oponente";
       fnEsperar();
    }

    // Devuelve el resultado
    return resultado;   
}

// función dispara flecha hacia Izquierda
int fnDispararIzquierda()
{
    // Variable para renglon y columna
    int renglon;
    int columna;

    // Obtiene las coordenadas de acuerdo al jugador en Turno
    if (gEnTurno==1)
    {
        renglon = gJugador1.fil;
        columna = gJugador1.col;
    }
    else
    {
        renglon = gJugador2.fil;
        columna = gJugador2.col;
    }

    // Resultado 
    int resultado = false;

    // fuera del Tablero
    int flechaSalioDelTablero = false;

    // Avance de la flecha
    int avanceFlecha = 0;
    
    // Ciclo para buscar hacia arriba
    while (avanceFlecha < ALCANCE_FLECHA)
    {
        // Incrementa el Avance de la Flecha
        avanceFlecha++;

        // decrementa la columna
        columna--;

        // Verifica que no haya salido del Tablero
        if (columna < 0)
        {
           // Salio del Tablero
           flechaSalioDelTablero = true;

           // Cambia el Resultado
           resultado = false;

           // Sale del Ciclo
           break;
        }

        // Verifica si hay un árbol
        if (fnPosicionTieneArbol(renglon,columna))
        {
           // Cambia el Resultado
           resultado = false;

           // Mensaje
           cout << "La Flecha se ha impactado con un Arbol";

           // Sale
           break;
        }
        else
        if (fnPosicionTieneJugador(renglon,columna))        
        {
            // Sale
            break;
        }
    }

    // Verifica si ha alcanzado oponente
    if (resultado)
    {
        // Mensaje
        cout << "! Exito ! La Flecha ha alcanzado al oponente";
        fnEsperar();
    }
    else   
    // Verifica si la flecha sale del Tablero
    if (flechaSalioDelTablero)
    {
        // Mensaje
        cout << "La Flecha salio del Tablero sin encontrar oponente";
        fnEsperar();
    }
    else
    // Verifica
    if (avanceFlecha == ALCANCE_FLECHA)
    {
        // Mensaje
        cout << "La Flecha alcanzo su distancia sin encontrar oponente";
        fnEsperar();
    }

    // Devuelve el resultado
    return resultado;   
}

// Verifica si la posición tiene un Jugador
bool fnPosicionTieneJugador(int ren, int col)
{
    // Verifica si hay Jugador 1
    if (gTablero[ren][col]=='1' || gTablero[ren][col]=='2')    
       return true;
    else
       return false;           
}
